/* 
	Name: Gabriel Meran
	Class : CS280
	Section : 3
	Program Name: Text Formater
	
	
*/
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

void format_text(ifstream &fileIn, char words);



int main (int argc, char *argv[] )
{
	char words;
	ifstream fileIn;
	
	if(argc != 5 )
	{
		cout << "usage:" << "<filename>\n";
	}
	else
	{
		fileIn(argv[1]);
	}
	
	if(!fileIn.is_open())
	{
		cout << "Could not open file \n";
	}
	
	else
	{
		char x;
		while(fileIn.get(x))
		{
			format_text(fileIn,words);
		}
	}
	
	
	
	fileIn.close();
	cin.get();
 	cin.ignore();
 	return 0;
	   

}

void format_text(ifstream &fileIn , char words)
{
	vector<char> word;
	char letter;
	int line_limit = 60; // default line length
	
	// reads in the each from a file
	while( (letter = fileIn.get()) != EOF) {
		
		
		word.push_back(letter);
		
	}
	
	// remove all tabs from the file
	for(int i = 0; i < word.size(); i ++) {
		
		if (word.at(i) =='\t')
		{
			word.erase(word.begin()+i);
		}
		
		
		// removes all enters from the file 
		if(word.at(i) == '\n')
		{
			word.erase(word.begin()+i);
			cout << ' ';
		}
		
		
		// removes any extra spaces from the file
		 if(word.at(i) == ' ' )
		{
			if(word.at(i+1) == ' ')
			{
				word.erase(word.begin()+i);
			}
		}
		
		cout << word.at(i);
		// limits the line to 60 chararcters per line and if a is broken adds a - to the line
		if((i+1) % line_limit == 0 ){
		
				cout<< '-' << endl;
		} 
			
		
		
	}
		

	
		
		
	
	
		
	
	
}
